﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Return : MonoBehaviour
{
    // int is
    MeshRenderer meshRenderer;
    public GameObject startPoint;

    int index = 0;
    float currentTIme = 0;
    float repeatTime = 8;
    public Material blue;
    public Material red;

    private void Start()
    {
        meshRenderer = GetComponent<MeshRenderer>();
    }

    private void Update()
    {
        currentTIme += Time.deltaTime;
        
        if(currentTIme < repeatTime / 2)
        {
            index = 0;
            meshRenderer.material = blue;
        }
        else if (currentTIme <= repeatTime)
        {
            index = 1;
            meshRenderer.material = red;
        }
        else
        {
            currentTIme = 0;
        }

    }

    void OnCollisionStay(Collision other)
    {
        if (index == 1)
        {
            other.transform.position = startPoint.transform.position;
        }
    }
}
