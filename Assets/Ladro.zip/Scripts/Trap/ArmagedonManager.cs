﻿using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public class ArmagedonManager : MonoBehaviour
{
    public GameObject armaPrefeb;

    Vector3 destination; // 바닥 착지지점
    Vector3 createPosition; // 상공 생성지점
    Vector3 dir; // 상공에서 바닥으로 향하는 방향

    int xRandom;
    int zRandom;

    float currentTime = 0;
    float spawnTime = 1.5f; 

    void Update()
    {
        currentTime += Time.deltaTime;

        if (currentTime > spawnTime)
        {
            xRandom = Random.Range(-73, 16);
            zRandom = Random.Range(52, 145);

            destination = new Vector3(xRandom, 0, zRandom);

            createPosition = destination + new Vector3(60, 143, 0);

            GameObject arma = Instantiate(armaPrefeb);
            arma.transform.position = createPosition;

            arma.GetComponent<Armagedon>().SetDestination(destination);

            currentTime = 0;
        }
    }



}
