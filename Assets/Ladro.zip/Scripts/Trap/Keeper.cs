﻿using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public class Keeper : MonoBehaviour
{
    float xRandom;
    float zRandom;

    bool isFind = false;
    bool isArrived = false;

    public float speed = 4f;

    Vector3 destPos;

    // Start is called before the first frame update
    void Start()
    {
        xRandom = Random.Range(10, 16);
        zRandom = Random.Range(126, 137);

        destPos = new Vector3(xRandom, 34.3f, zRandom);

        print(destPos.x + "/" + destPos.z);

    }

    // Update is called once per frame
    void Update()
    {
        if(!isFind)
        {
            Vector3 dir = destPos - transform.position;
            dir.Normalize();

            if (!isArrived)
            {
                transform.position += dir * speed * Time.deltaTime;

                float distance = Vector3.Distance(destPos, transform.position);

                if (distance < 0.1)
                {
                    isArrived = true;
                }
            }
            else
            {
                xRandom = Random.Range(10, 16);
                zRandom = Random.Range(126, 137);

                destPos = new Vector3(xRandom, 34.3f, zRandom);
                isArrived = false;
            }
        }
    }

    void OnCollisionEnter(Collision collision)
    {
        // isFind = true;
    }

}
