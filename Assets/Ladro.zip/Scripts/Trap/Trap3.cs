﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Trap3 : MonoBehaviour
{
    public GameObject trap3;
    // float speed = 3f;

    int index = 0;

    Vector3 destPos = new Vector3(-12.97f, 14.8f, 113.9f);

    private void Update()
    {
        if (index == 1)
        {
            if (Vector3.Distance(transform.position, trap3.transform.position) > 0.5)
            {
                trap3.transform.position = Vector3.Lerp(trap3.transform.position, destPos, 0.01f);
            }
            else
            {
                index = 2;
            }
        }
    }

    private void OnCollisionEnter(Collision other)
    {
        if (index == 0)
        {
            if (other.gameObject.name.Contains("Player"))
            {
                index = 1;
            }
        }
    }
}
