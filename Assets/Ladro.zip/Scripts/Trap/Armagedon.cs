﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Armagedon : MonoBehaviour
{
    public float speed = 40;

    Vector3 target;
    Vector3 dir;

    void Start()
    {
        dir = target - transform.position;
        dir.Normalize();

        transform.LookAt(dir);
    }

    void Update()
    {
        transform.position += dir * speed * Time.deltaTime;
    }

    private void OnCollisionEnter(Collision other)
    {
        Destroy(gameObject);
    }

    public void SetDestination(Vector3 dest)
    {
        target = dest;
    }

}
